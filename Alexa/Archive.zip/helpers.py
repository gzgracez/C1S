import requests
import json
import datetime
import pymysql
import sys
#rds settings
rds_host  = "allskill-db.cbzix5fu8xra.us-east-1.rds.amazonaws.com"
name = "allskill"
password = "noskill123"
db_name = "allskill"

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5, port=3306)
except Exception as e:
    print("ERROR: Unexpected error: Could not connect to MySql instance. \nError: {error}".format(error=e))
    sys.exit()

print("SUCCESS: Connection to RDS mysql instance succeeded")

def handler(event, context):
    
    item_count = 0

    with conn.cursor() as cur:
        cur.execute("create table Employee3 ( EmpID  int NOT NULL, Name varchar(255) NOT NULL, PRIMARY KEY (EmpID))")  
        cur.execute('insert into Employee3 (EmpID, Name) values(1, "Joe")')
        cur.execute('insert into Employee3 (EmpID, Name) values(2, "Bob")')
        cur.execute('insert into Employee3 (EmpID, Name) values(3, "Mary")')
        conn.commit()
        cur.execute("select * from Employee3")
        for row in cur:
            item_count += 1
            logger.info(row)
            #print(row)
    return "Added %d items from RDS MySQL table" %(item_count)

apiKey = "638e3a40768577cc14440e93f78f7085"

# returns array of accounts
def getAccounts(customerID):
    accountsUrl = 'http://api.reimaginebanking.com/customers/{}/accounts?key={}'.format(customerID, apiKey)
    accountsResponse = requests.get(accountsUrl)
    if accountsResponse.status_code == 200:
        accounts = json.loads(accountsResponse.text)
        return accounts
    else:
        return None

# returns a dictionary: {accountID, [account name, balance]}
def getAccountAndBalance(customerID):
    accounts = getAccounts(customerID)
    ab = {}
    for i in accounts:
        ab[i["_id"]] = [i["nickname"], i["balance"]]
    return ab

# returns integer of current checking balance
def getCheckingBalance(customerID):
    accounts = getAccounts(customerID)
    checking = 0
    for i in accounts:
        if i["type"].lower() == "checking":
            checking += i["balance"]
    return checking

# returns integer of current credit card balance
def getCreditCardBalance(customerID):
    accounts = getAccounts(customerID)
    credit = 0
    for i in accounts:
        if i["type"].lower() == "credit card":
            credit += i["balance"]
    return credit

# returns integer of current balance (checking - credit card)
def getTotalBalance(customerID):
    accounts = getAccounts(customerID)
    current = 0
    for i in accounts:
        if i["type"].lower() == "credit card":
            current -= i["balance"]
        elif i["type"].lower() == "checking":
            current += i["balance"]
        else:
            continue
    return current

# returns a dictionary of all purchases: {purchaseID, [merchantID, purchaseDate, amount]}
def getPurchases(customerID):
    accounts = getAccounts(customerID)
    for i in accounts:
        accountID = i["_id"]
        purchasesUrl = 'http://api.reimaginebanking.com/accounts/{}/purchases?key={}'.format(accountID, apiKey)
        purchases = {}
        purchasesResponse = requests.get(purchasesUrl)
        if purchasesResponse.status_code == 200:
            purchasesJSON = json.loads(purchasesResponse.text)
            for i in purchasesJSON:
                if i["medium"].lower() == "balance":
                    purchases[i["_id"]] = [i["merchant_id"], i["purchase_date"], i["amount"]]
            return purchases
        else:
            return None

def getCategoryTotalforDOW(customerID, category, day):
    total = 0
    count = 0
    purchases = getPurchases(customerID)
    for i in purchases:
        merchantID = purchases[i][0]
        merchantUrl = 'http://api.reimaginebanking.com/merchants/{}?key={}'.format(merchantID, apiKey)
        merchantResponse = requests.get(merchantUrl)
        if merchantResponse.status_code == 200:
            merchantJSON = json.loads(merchantResponse.text)
            categories = merchantJSON["category"]
            cat = ""
            if len(categories) < 0:
                cat = "misc"
            else:
                cat = categories[0]
            # print cat
            # print purchases[i][2]
            dow = datetime.datetime.strptime(purchases[i][1], '%Y-%m-%d').date().weekday()
            if dow == day and cat.lower() == category.lower():
                total += purchases[i][2]
                count += 1
                print cat
                print purchases[i][2]
        else:
            continue
    return [total, count]

def getTotalforDOW(customerID, day):
    total = 0
    count = 0
    purchases = getPurchases(customerID)
    for i in purchases:
        dow = datetime.datetime.strptime(purchases[i][1], '%Y-%m-%d').date().weekday()
        if dow == day:
            total += purchases[i][2]
            count += 1
    return [total, count]

# calculate suggested spending for a category for today
# calculateSuggestedByCategory("58000d58360f81f104543d82", "food", 3)
def calculateSuggestedByCategory(customerID, category, dow):
    total = getCategoryTotalforDOW(customerID, category, dow)
    avg = total[0] / total[1]
    currentBalance = getTotalBalance(customerID)
    if avg > currentBalance:
        totalBalance = getTotalBalance(customerID)
        fraction = total[0] / totalBalance
        return fraction * totalBalance
    else:
        return avg

# calculate suggested spending overall for today
# calculateSuggestedToday("58000d58360f81f104543d82", 3)
def calculateSuggestedToday(customerID, dow):
    total = getTotalforDOW(customerID, dow)
    avg = total[0] / total[1] if total[1] else total[1]
    currentBalance = getTotalBalance(customerID)
    if avg > currentBalance:
        totalBalance = getTotalBalance(customerID)
        fraction = total[0] / totalBalance
        return fraction * totalBalance
    else:
        return avg

# if __name__=="__main__":
    # print getCategoryTotalforDOW("58000d58360f81f104543d82", "food", 3)
    # print getTotalBalance("58000d58360f81f104543d82")
    # print calculateSuggestedByCategory("58000d58360f81f104543d82", "food", 3)